# Spammer-Grab
Spams GAC (Grab Activation Code) SMS to a phone number repeatedly per 60 second. "Spammer" uses Grab passenger API to make the GAC sms sent. "Spammer" is tested under Python 2.7. NOTE: THIS TOOL IS NOT WORKING SINCE JANUARY 2018.
# How to use?
Just type 'python Spammer.py -h' to show the help message.
# Me
E-Mail: p4kl0nc4t@obsidiancyberteam.id
Do not hesitate to contact me :)
